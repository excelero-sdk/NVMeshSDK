class AttributeRepresentation(object):
    def __init__(self, display, dbKey, type=None):
        self.display = display
        self.dbKey = dbKey
        self.type = type